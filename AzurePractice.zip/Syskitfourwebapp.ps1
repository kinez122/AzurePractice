$resourcegroup = "Practice_DevOps"
$name = "syskitfourwebapp"
$location = "West Europe"
$appservice = "ASP-PracticeDevOps-82ae"

New-AzWebApp -ResourceGroupName $resourcegroup -Name $name -Location $location -AppServicePlan $appservice